"""All functionality concerned with presentation to the user."""
from pandas_profiling.report.structure.report import get_report_structure

__all__ = ["get_report_structure"]
