===
API
===

.. toctree::

    api/profile_report
    api/settings
    api/controller
    api/model
    api/report
    api/utils
    api/visualisation
