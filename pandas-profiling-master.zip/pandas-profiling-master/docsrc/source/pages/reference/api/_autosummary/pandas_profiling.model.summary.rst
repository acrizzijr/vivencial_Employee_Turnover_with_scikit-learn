﻿pandas\_profiling.model.summary
===============================

.. automodule:: pandas_profiling.model.summary

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      describe_1d
      get_series_descriptions
   
   

   
   
   

   
   
   



