﻿pandas\_profiling.report.presentation.core.frequency\_table
===========================================================

.. automodule:: pandas_profiling.report.presentation.core.frequency_table

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      FrequencyTable
   
   

   
   
   



