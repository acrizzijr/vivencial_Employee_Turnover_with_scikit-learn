﻿pandas\_profiling.config.UrlVars
================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: UrlVars