﻿pandas\_profiling.config.Settings
=================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_settings:: Settings