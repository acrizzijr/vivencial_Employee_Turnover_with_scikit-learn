﻿pandas\_profiling.report.presentation.core.variable\_info
=========================================================

.. automodule:: pandas_profiling.report.presentation.core.variable_info

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      VariableInfo
   
   

   
   
   



