﻿pandas\_profiling.config.PathVars
=================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: PathVars