﻿pandas\_profiling.config.Style
==============================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Style