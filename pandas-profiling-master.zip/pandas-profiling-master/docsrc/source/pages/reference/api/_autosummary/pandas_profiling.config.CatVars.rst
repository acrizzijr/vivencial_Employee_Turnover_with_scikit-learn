﻿pandas\_profiling.config.CatVars
================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: CatVars