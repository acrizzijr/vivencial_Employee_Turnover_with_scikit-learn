﻿pandas\_profiling.config.FileVars
=================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: FileVars