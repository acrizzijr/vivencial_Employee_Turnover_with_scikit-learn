﻿pandas\_profiling.report.presentation.core.toggle\_button
=========================================================

.. automodule:: pandas_profiling.report.presentation.core.toggle_button

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      ToggleButton
   
   

   
   
   



