﻿pandas\_profiling.config.CorrelationPlot
========================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: CorrelationPlot