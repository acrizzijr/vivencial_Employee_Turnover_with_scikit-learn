﻿pandas\_profiling.config.Correlation
====================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Correlation