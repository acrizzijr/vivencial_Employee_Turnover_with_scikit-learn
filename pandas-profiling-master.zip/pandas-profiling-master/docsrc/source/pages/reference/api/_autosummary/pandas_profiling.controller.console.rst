﻿pandas\_profiling.controller.console
====================================

.. automodule:: pandas_profiling.controller.console

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      main
      parse_args
   
   

   
   
   

   
   
   



