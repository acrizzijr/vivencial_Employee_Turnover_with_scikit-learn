﻿pandas\_profiling.controller.pandas\_decorator
==============================================

.. automodule:: pandas_profiling.controller.pandas_decorator

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      profile_report
   
   

   
   
   

   
   
   



