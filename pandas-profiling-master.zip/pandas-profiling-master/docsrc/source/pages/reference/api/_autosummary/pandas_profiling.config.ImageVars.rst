﻿pandas\_profiling.config.ImageVars
==================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: ImageVars