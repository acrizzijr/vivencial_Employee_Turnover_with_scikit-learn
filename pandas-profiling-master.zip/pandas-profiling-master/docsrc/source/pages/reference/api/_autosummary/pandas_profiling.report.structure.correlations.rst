﻿pandas\_profiling.report.structure.correlations
===============================================

.. automodule:: pandas_profiling.report.structure.correlations

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_correlation_items
   
   

   
   
   

   
   
   



