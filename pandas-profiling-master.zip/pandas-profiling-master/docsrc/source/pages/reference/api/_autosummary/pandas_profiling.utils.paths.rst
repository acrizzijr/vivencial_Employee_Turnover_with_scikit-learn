﻿pandas\_profiling.utils.paths
=============================

.. automodule:: pandas_profiling.utils.paths

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_config
      get_data_path
      get_html_template_path
      get_project_root
   
   

   
   
   

   
   
   



