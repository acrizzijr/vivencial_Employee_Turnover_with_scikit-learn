﻿pandas\_profiling.utils.dataframe
=================================

.. automodule:: pandas_profiling.utils.dataframe

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      expand_mixed
      hash_dataframe
      is_supported_compression
      read_pandas
      remove_suffix
      rename_index
      slugify
      sort_column_names
      uncompressed_extension
      warn_read
   
   

   
   
   

   
   
   



