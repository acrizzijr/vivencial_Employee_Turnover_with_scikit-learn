﻿pandas\_profiling.config.Samples
================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Samples