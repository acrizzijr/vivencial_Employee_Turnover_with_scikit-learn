﻿pandas\_profiling.report.structure.overview
===========================================

.. automodule:: pandas_profiling.report.structure.overview

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_dataset_alerts
      get_dataset_column_definitions
      get_dataset_items
      get_dataset_overview
      get_dataset_reproduction
      get_dataset_schema
   
   

   
   
   

   
   
   



