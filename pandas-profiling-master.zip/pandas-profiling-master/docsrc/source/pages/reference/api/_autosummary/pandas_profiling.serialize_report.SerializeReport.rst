﻿pandas\_profiling.serialize\_report.SerializeReport
===================================================

.. currentmodule:: pandas_profiling.serialize_report

.. autoclass:: SerializeReport

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SerializeReport.__init__
      ~SerializeReport.dump
      ~SerializeReport.dumps
      ~SerializeReport.load
      ~SerializeReport.loads
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SerializeReport.config
      ~SerializeReport.df
      ~SerializeReport.df_hash
   
   