﻿pandas\_profiling.report.structure.report
=========================================

.. automodule:: pandas_profiling.report.structure.report

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_definition_items
      get_duplicates_items
      get_missing_items
      get_report_structure
      get_sample_items
      get_scatter_matrix
      render_variables_section
   
   

   
   
   

   
   
   



