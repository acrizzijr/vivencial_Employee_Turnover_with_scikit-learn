﻿pandas\_profiling.config.ImageType
==================================

.. currentmodule:: pandas_profiling.config

.. autoclass:: ImageType

   
   .. automethod:: __init__

   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ImageType.svg
      ~ImageType.png
   
   