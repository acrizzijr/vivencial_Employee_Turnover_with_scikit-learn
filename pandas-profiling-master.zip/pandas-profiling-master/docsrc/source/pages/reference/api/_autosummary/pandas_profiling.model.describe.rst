﻿pandas\_profiling.model.describe
================================

.. automodule:: pandas_profiling.model.describe

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      describe
   
   

   
   
   

   
   
   



