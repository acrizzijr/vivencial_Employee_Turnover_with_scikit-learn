﻿pandas\_profiling.model.summarizer
==================================

.. automodule:: pandas_profiling.model.summarizer

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      format_summary
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      BaseSummarizer
      PandasProfilingSummarizer
   
   

   
   
   



