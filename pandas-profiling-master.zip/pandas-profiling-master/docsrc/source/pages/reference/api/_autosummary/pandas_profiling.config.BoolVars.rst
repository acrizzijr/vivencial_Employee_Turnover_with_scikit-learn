﻿pandas\_profiling.config.BoolVars
=================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: BoolVars