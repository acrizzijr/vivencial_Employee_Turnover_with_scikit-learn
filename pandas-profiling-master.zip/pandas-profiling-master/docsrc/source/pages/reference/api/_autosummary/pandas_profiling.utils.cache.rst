﻿pandas\_profiling.utils.cache
=============================

.. automodule:: pandas_profiling.utils.cache

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      cache_file
      cache_zipped_file
   
   

   
   
   

   
   
   



