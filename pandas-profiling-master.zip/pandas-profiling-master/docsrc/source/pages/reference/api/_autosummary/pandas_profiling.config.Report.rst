﻿pandas\_profiling.config.Report
===============================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Report