﻿pandas\_profiling.model.handler
===============================

.. automodule:: pandas_profiling.model.handler

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      compose
      get_render_map
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Handler
   
   

   
   
   



