﻿pandas\_profiling.visualisation.plot
====================================

.. automodule:: pandas_profiling.visualisation.plot

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      cat_frequency_plot
      correlation_matrix
      get_cmap_half
      get_correlation_font_size
      histogram
      mini_histogram
      scatter_complex
      scatter_pairwise
      scatter_series
   
   

   
   
   

   
   
   



