﻿pandas\_profiling.config.MissingPlot
====================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: MissingPlot