﻿pandas\_profiling.config.Dataset
================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Dataset