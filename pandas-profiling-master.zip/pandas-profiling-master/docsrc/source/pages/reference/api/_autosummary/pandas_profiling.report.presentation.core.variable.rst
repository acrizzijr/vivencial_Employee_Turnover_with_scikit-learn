﻿pandas\_profiling.report.presentation.core.variable
===================================================

.. automodule:: pandas_profiling.report.presentation.core.variable

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Variable
   
   

   
   
   



