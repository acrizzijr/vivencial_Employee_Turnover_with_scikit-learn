﻿pandas\_profiling.model.duplicates
==================================

.. automodule:: pandas_profiling.model.duplicates

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_duplicates
   
   

   
   
   

   
   
   



