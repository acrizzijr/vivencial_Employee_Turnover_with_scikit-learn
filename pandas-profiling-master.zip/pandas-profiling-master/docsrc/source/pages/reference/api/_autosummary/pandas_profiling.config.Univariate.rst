﻿pandas\_profiling.config.Univariate
===================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Univariate