﻿pandas\_profiling.model.summary\_algorithms
===========================================

.. automodule:: pandas_profiling.model.summary_algorithms

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      chi_square
      describe_boolean_1d
      describe_categorical_1d
      describe_counts
      describe_date_1d
      describe_file_1d
      describe_generic
      describe_image_1d
      describe_numeric_1d
      describe_path_1d
      describe_supported
      describe_url_1d
      func_nullable_series_contains
      histogram_compute
      named_aggregate_summary
      series_handle_nulls
      series_hashable
   
   

   
   
   

   
   
   



