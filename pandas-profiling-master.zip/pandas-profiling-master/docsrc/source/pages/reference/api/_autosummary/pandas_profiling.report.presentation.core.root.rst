﻿pandas\_profiling.report.presentation.core.root
===============================================

.. automodule:: pandas_profiling.report.presentation.core.root

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Root
   
   

   
   
   



