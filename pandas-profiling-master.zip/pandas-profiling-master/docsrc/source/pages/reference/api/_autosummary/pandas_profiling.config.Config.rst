﻿pandas\_profiling.config.Config
===============================

.. currentmodule:: pandas_profiling.config

.. autoclass:: Config

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Config.__init__
      ~Config.get_arg_groups
      ~Config.shorthands
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Config.arg_groups
   
   