﻿pandas\_profiling.report.presentation.core.collapse
===================================================

.. automodule:: pandas_profiling.report.presentation.core.collapse

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Collapse
   
   

   
   
   



