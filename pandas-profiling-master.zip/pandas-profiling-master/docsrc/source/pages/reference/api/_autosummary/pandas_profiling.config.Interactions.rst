﻿pandas\_profiling.config.Interactions
=====================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Interactions