﻿pandas\_profiling.config.Duplicates
===================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Duplicates