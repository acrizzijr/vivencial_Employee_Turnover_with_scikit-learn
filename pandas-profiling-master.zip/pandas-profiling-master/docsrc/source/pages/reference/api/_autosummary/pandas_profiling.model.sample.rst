﻿pandas\_profiling.model.sample
==============================

.. automodule:: pandas_profiling.model.sample

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      get_custom_sample
      get_sample
   
   

   
   
   

   
   
   



