﻿pandas\_profiling.model.typeset\_relations
==========================================

.. automodule:: pandas_profiling.model.typeset_relations

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      category_is_numeric
      category_to_numeric
      is_nullable
      numeric_is_category
      object_is_bool
      series_is_string
      string_is_bool
      string_to_bool
      to_bool
      to_category
      try_func
   
   

   
   
   

   
   
   



