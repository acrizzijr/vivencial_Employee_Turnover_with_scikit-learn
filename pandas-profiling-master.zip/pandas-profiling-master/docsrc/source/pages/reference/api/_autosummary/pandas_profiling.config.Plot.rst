﻿pandas\_profiling.config.Plot
=============================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Plot