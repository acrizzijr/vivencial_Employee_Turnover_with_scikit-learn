﻿pandas\_profiling.config.Theme
==============================

.. currentmodule:: pandas_profiling.config

.. autoclass:: Theme

   
   .. automethod:: __init__

   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Theme.united
      ~Theme.flatly
   
   