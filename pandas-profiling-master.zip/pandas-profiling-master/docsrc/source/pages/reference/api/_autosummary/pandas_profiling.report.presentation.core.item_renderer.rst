﻿pandas\_profiling.report.presentation.core.item\_renderer
=========================================================

.. automodule:: pandas_profiling.report.presentation.core.item_renderer

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      ItemRenderer
   
   

   
   
   



