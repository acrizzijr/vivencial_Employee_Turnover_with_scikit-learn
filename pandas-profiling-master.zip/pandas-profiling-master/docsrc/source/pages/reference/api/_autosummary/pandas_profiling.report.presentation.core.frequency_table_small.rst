﻿pandas\_profiling.report.presentation.core.frequency\_table\_small
==================================================================

.. automodule:: pandas_profiling.report.presentation.core.frequency_table_small

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      FrequencyTableSmall
   
   

   
   
   



