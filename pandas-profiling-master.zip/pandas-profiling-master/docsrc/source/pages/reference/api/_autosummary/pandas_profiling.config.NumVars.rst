﻿pandas\_profiling.config.NumVars
================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: NumVars