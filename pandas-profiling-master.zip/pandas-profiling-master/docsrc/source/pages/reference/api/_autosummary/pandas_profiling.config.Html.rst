﻿pandas\_profiling.config.Html
=============================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Html