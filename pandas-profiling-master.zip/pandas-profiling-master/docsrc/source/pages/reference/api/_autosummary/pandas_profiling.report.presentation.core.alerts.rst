﻿pandas\_profiling.report.presentation.core.alerts
=================================================

.. automodule:: pandas_profiling.report.presentation.core.alerts

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Alerts
   
   

   
   
   



