﻿pandas\_profiling.config.Variables
==================================

.. currentmodule:: pandas_profiling.config

.. autopydantic_model:: Variables