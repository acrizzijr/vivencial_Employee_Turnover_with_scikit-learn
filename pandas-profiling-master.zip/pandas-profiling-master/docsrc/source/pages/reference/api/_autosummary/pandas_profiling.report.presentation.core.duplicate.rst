﻿pandas\_profiling.report.presentation.core.duplicate
====================================================

.. automodule:: pandas_profiling.report.presentation.core.duplicate

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Duplicate
   
   

   
   
   



