==========
Controller
==========

.. currentmodule:: pandas_profiling.controller
.. toctree::

.. autosummary::
   :toctree: _autosummary

   console
   pandas_decorator
